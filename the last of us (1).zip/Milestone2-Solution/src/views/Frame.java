package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import model.characters.Character;
import model.characters.Direction;
import model.characters.Explorer;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;

public class Frame extends JFrame implements ActionListener, KeyListener {
	private JLabel panel1;
	private JPanel panel2;
	private Hero selectedHero;
	private JButton[] avaHeroes;
	private JLabel[] messageLabel;
	private JButton startGame;
	private JPanel backgroundPanel;
	private JButton clickToPlay;
	private JPanel gamePanel1;
	private JButton[][] gridButtons;
	private ArrayList<String> imagePaths;
	private JButton attack;
	private JButton cure;
	private JButton useSpecial;
	private JButton endTurn;
	private JButton right;
	private JButton left;
	private JButton up;
	private JButton down;
	private Character Target;
	private JLabel characterInfo;
	 private ButtonGroup   heroButtonGroup;
	 private JRadioButton[] heroRadioButtons;

////////////////////////////WINDOW1////////////////////////////////
	public Frame() {

		this.setTitle("TheLastOfUs");

		backgroundPanel = new JPanel() {
			protected void paintComponent(Graphics g) {
				ImageIcon imageIcon = new ImageIcon("window1.jpg");
				g.drawImage(imageIcon.getImage(), 0, 0, getWidth(), getHeight(), null);
			}

		};
		backgroundPanel.setLayout(new BorderLayout());

		this.getContentPane().add(backgroundPanel);

		clickToPlay = new JButton("Click to Play");

		clickToPlay.setOpaque(false);
		clickToPlay.setContentAreaFilled(false);
		clickToPlay.setBorderPainted(false);
		clickToPlay.setForeground(Color.WHITE);
		clickToPlay.setFont(new Font("Serif", Font.BOLD, 25));
		backgroundPanel.add(clickToPlay, BorderLayout.SOUTH);
		clickToPlay.addActionListener(this);

//   this.setVisible(true);	
		ImageIcon logo = new ImageIcon("logo.png");
		this.setIconImage(logo.getImage());
		this.setSize(1500, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		
	}

	//////////////// WINDOW2//////////////////////////////
	public void Window2() {

		panel1 = new JLabel(new ImageIcon("grid.jpg"));
		panel2 = new JPanel();
		panel2.setBackground(Color.GRAY);
		panel1.setBackground(Color.BLACK);

		panel1.setLayout(new GridLayout());
		panel2.setLayout(new FlowLayout(FlowLayout.RIGHT));
		this.getContentPane().add(panel1);
		this.getContentPane().add(panel2);


		try {
			Game.loadHeroes("Heroes.csv");
		} catch (IOException e) {
			JOptionPane.showConfirmDialog(this, "no available heros", "error", JOptionPane.ERROR_MESSAGE);
			return;

		}
		imagePaths = new ArrayList<>();
		imagePaths.add("Joel Miller.jpg");
		imagePaths.add("Ellie Williams.jpg");
		imagePaths.add("Tess.jpg");
		imagePaths.add("Riley Abel.jpg");
		imagePaths.add("Tommy Miller.jpg");
		imagePaths.add("Bill.jpg");
		imagePaths.add("David.jpg");
		imagePaths.add("Henry Burell.jpg");

		messageLabel = new JLabel[Game.availableHeroes.size()];

		for (int i = 0; i < messageLabel.length; i++) {
			messageLabel[i] = new JLabel(getHeroInfo(Game.availableHeroes.get(i)));
			panel2.add(messageLabel[i]);
			messageLabel[i].setVisible(false);
			messageLabel[i].setForeground(Color.WHITE);
		}
		avaHeroes = new JButton[Game.availableHeroes.size()];
		for (int h = 0; h < avaHeroes.length; h++) {
			for (int i = 0; i < imagePaths.size(); i++) {
				if (h == i) {
					avaHeroes[h] = new JButton();////////// not sure///////////
					panel1.add(avaHeroes[h]);
					panel1.setLayout(new GridLayout(4, 2));
					avaHeroes[h].setIcon(new ImageIcon(imagePaths.get(i)));
//	            avaHeroes[h].setVisible(true);/////??????
					avaHeroes[h].addActionListener(this);
					avaHeroes[h].setOpaque(false);
					avaHeroes[h].setContentAreaFilled(false);
					avaHeroes[h].setBorderPainted(false);

				}
			}

		}
		this.add(panel1, BorderLayout.CENTER);
		this.add(panel2, BorderLayout.EAST);
		startGame = new JButton("Start");
		this.add(startGame, BorderLayout.SOUTH);
		startGame.setOpaque(false);
		startGame.setContentAreaFilled(false);
		startGame.setBorderPainted(false);
		startGame.setForeground(Color.BLACK);
		startGame.setFont(new Font("Serif", Font.BOLD, 25));
		startGame.addActionListener(this);

		ImageIcon logo = new ImageIcon("logo.png");
		this.setIconImage(logo.getImage());
		

	}

	////////////////////////////// BUTTONS/////////////////////////////////
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == clickToPlay) {
			backgroundPanel.setVisible(false);
			Window2();
			return;
		}
		for (int h = 0; h < avaHeroes.length; h++) {
			if (e.getSource() == avaHeroes[h]) {
				selectedHero = Game.availableHeroes.get(h);
				for (int i = 0; i < messageLabel.length; i++) {
					if (i == h) {
						messageLabel[i].setVisible(true);
					} else {
						messageLabel[i].setVisible(false);
					}
				}
				return;
			}
		}
		if (e.getSource() == startGame) {
			newGame();

			return;
		}
		for (int i = 0; i < gridButtons.length; i++) {
			for (int j = 0; j < gridButtons.length; j++) {
				if (e.getSource() == gridButtons[i][j]) {
					if (Game.map[i][j] instanceof CharacterCell) {
						CharacterCell c = (CharacterCell) Game.map[i][j];
//						if (c.getCharacter() instanceof Hero) {
//							selectedHero = (Hero) c.getCharacter();
//							characterInfo.setText(getHeroInfo(selectedHero));
//							characterInfo.setForeground(Color.WHITE);
						  if (c.getCharacter() instanceof Zombie) {
							Target = (Zombie) c.getCharacter();
							characterInfo.setText(getZombieInfo((Zombie) Target));
						}
					}
				}
			}}
//			JRadioButton selectedRadioButton = (JRadioButton) e.getSource();
//            if (selectedRadioButton.isSelected()) {
//            	selectedHero=
		
		for(int i=0;i<Game.heroes.size();i++) {///////
    if (e.getSource()==Game.heroes.get(i)) {////////not added yet
    	selectedHero=Game.heroes.get(i);//////////
    }
		
            }
		
		if (e.getSource().equals(attack)) {
			try {
				selectedHero.setTarget(Target);
				selectedHero.attack();
				Target = null;
				selectedHero.setTarget(null);
				showMapOnButtons();
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
			} catch (NotEnoughActionsException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		if (e.getSource().equals(cure)) {
			try {
				selectedHero.setTarget(Target);
				selectedHero.cure();
				selectedHero.setTarget(null);
				Target = null;
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
				
				showMapOnButtons();
				selectedHelper();
			} catch (NoAvailableResourcesException | InvalidTargetException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}

		if (e.getSource().equals(useSpecial)) {
			try {
				selectedHero.setTarget(Target);
				selectedHero.useSpecial();
				selectedHero.setTarget(null);

				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
				showMapOnButtons();
			} catch (NoAvailableResourcesException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		if (e.getSource().equals(endTurn)) {
			try {
				Game.endTurn();
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
				showMapOnButtons();
			} catch (NotEnoughActionsException | InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		if (e.getSource().equals(up)) {
			try {
				selectedHero.move(Direction.UP);
				showMapOnButtons();
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
			
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		if (e.getSource().equals(down)) {
			try {
				selectedHero.move(Direction.DOWN);
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		if (e.getSource().equals(right)) {
			try {
				selectedHero.move(Direction.RIGHT);
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setForeground(Color.WHITE);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		if (e.getSource().equals(left)) {
			try {
				selectedHero.move(Direction.LEFT);
				characterInfo.setText(getHeroInfo(selectedHero));
				characterInfo.setBackground(Color.WHITE);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}

		}

		if (Game.checkWin()) {
			JOptionPane.showMessageDialog(this, "Congratulations! You win");
		} else if (Game.checkGameOver()) {
			JOptionPane.showMessageDialog(this, "Congratulations! You lose");
		}
	}

	public void newGame() {
		Game.startGame(selectedHero);
		panel1.setVisible(false);
		panel2.setVisible(false);
		startGame.setVisible(false);
		this.getContentPane().setLayout(null);

		JLabel l = new JLabel(new ImageIcon("grid2.jpg"));
		this.getContentPane().add(l);
		l.setVisible(true);
		l.setBounds(0,0,1360,780);
		gamePanel1 = new JPanel();
		gamePanel1.setLayout(new GridLayout(0, 1)); // One column
		gamePanel1.setBounds(10, 50, 150, 250);
		l.add(gamePanel1);
		gamePanel1.setVisible(true);
		gamePanel1.setEnabled(true);

		attack = new JButton("Attack");
		attack.addActionListener(this);
		
		gamePanel1.add(attack);

		cure = new JButton("Cure");
		cure.addActionListener(this);
		gamePanel1.add(cure);

		useSpecial = new JButton("Use Special");
		useSpecial.addActionListener(this);
		gamePanel1.add(useSpecial);

		endTurn = new JButton("End Turn");
		endTurn.addActionListener(this);
		gamePanel1.add(endTurn);

		down = new JButton("up");
		down.addActionListener(this);
		gamePanel1.add(down);

		up = new JButton("down");
		up.addActionListener(this);
		gamePanel1.add(up);

		right = new JButton("right");
		right.addActionListener(this);
		gamePanel1.add(right);

		left = new JButton("left");
		left.addActionListener(this);
		gamePanel1.add(left);

		JPanel grid = new JPanel();
		grid.setLayout(new GridLayout(15, 15));
		grid.setBounds(500, 50, 600, 600);
		l.add(grid);
		grid.setVisible(true);
		grid.setEnabled(true);

		characterInfo = new JLabel();
		characterInfo.setBounds(10, 250, 300, 300);
		characterInfo.setBackground(Color.WHITE);
		l.add(characterInfo);
		
		JLabel titleLabel = new JLabel("Select a Hero:");
	    titleLabel.setForeground(Color.BLACK);
	    titleLabel.setFont(new Font("Serif", Font.BOLD, 20));
	    gamePanel1.add(titleLabel);
	    heroButtonGroup = new ButtonGroup();
	    for (int i = 0; i < Game.heroes.size(); i++) {
	     heroRadioButtons = new JRadioButton[Game.heroes.size()];
		 heroRadioButtons[i] = new JRadioButton( Game.heroes.get(i).getName());
	        heroButtonGroup.add(heroRadioButtons[i]);
	        gamePanel1.add(heroRadioButtons[i]);
	        }
		

		gridButtons = new JButton[15][15];
		for (int i = 0; i < gridButtons.length; i++) {
			for (int j = 0; j < gridButtons[i].length; j++) {
				JButton gbutton = new JButton();

				gbutton.setFont(new Font("Serif", Font.ITALIC | Font.BOLD, 7));
				gridButtons[i][j] = gbutton;
				grid.add(gbutton);
				gbutton.addActionListener(this);
				gridButtons[i][j].addKeyListener(this);
			}
		}
		this.addKeyListener( this);
		this.requestFocus();
		showMapOnButtons();
	}
	///////////////////////////////////////////////////////
	public void selectedHelper() {
     
    for (int i = 1; i < Game.heroes.size(); i++) {
       
        for(int j=0;j<heroRadioButtons.length;j++) {
        	if(heroRadioButtons[j].getName()==Game.heroes.get(i).getName())
        		return;
        	else {
        		 heroRadioButtons[i] = new JRadioButton( Game.heroes.get(i).getName());
        heroButtonGroup.add(heroRadioButtons[i]);
        gamePanel1.add(heroRadioButtons[i]);
        	}
    }}
    }
	
	
	
	
	
	
	

	public void showMapOnButtons() {
		for (int i = 0; i < gridButtons.length; i++) {
			for (int j = 0; j < gridButtons[i].length; j++) {
				gridButtons[i][j].setIcon(null);
				gridButtons[i][j].setText("");
				if (!Game.map[i][j].isVisible()) {
					gridButtons[i][j].setBackground(Color.BLACK);
				} else {
					if (Game.map[i][j] instanceof CharacterCell) {
						CharacterCell c = (CharacterCell) Game.map[i][j];
						if (c.getCharacter() == null) {
							gridButtons[i][j].setBackground(Color.white);
						} else if (c.getCharacter() instanceof Zombie) {
							gridButtons[i][j].setIcon(new ImageIcon("zombie.jpg"));
						} else if (c.getCharacter() instanceof Hero) {

							ImageIcon image = new ImageIcon(selectedHero.getName() + ".jpg");
						
							gridButtons[i][j].setIcon(image);

						}
//						else if(Game.map[i][j] instanceof TrapCell ) {
//							if( ((CharacterCell) Game.map[i][j])).getCharacter()!=null ){
//								JOptionPane.showMessageDialog(this, "you entered a trapCell!!!!");}}
//							}
					} else if (Game.map[i][j] instanceof CollectibleCell) {
						CollectibleCell cc = (CollectibleCell) Game.map[i][j];
						if (cc.getCollectible() instanceof Supply) {// put another image
							gridButtons[i][j].setIcon(
									new ImageIcon("lightning-logo-template-vector-flat-260nw-1714169530.webp"));

//						} else if (Game.map[i][j] instanceof TrapCell) {
//							JOptionPane.showMessageDialog(this, "you entered a trapCell!!!!");

		   
						} else {
							gridButtons[i][j].setIcon(new ImageIcon("vaccine.png"));
						}
					}
				}
			}
		}
	}

	public String getHeroInfo(Hero h) {
		String t;
		if (h instanceof Medic)
			t = "Medic";
		else if (h instanceof Explorer)
			t = "Explorer";
		else
			t = "Fighter";

		// Customize the font and placement using HTML tags
		String s = "<html><p style='font-family: Monospace ; font-size: 10px;'>" + " " + "<br>" + "  " + "<br>" + "  "
				+ "<br>" + "  " + "<br>" + "  " + "<br>" + "<b>Type:</b> " + t + "<br>" + "<b>Name:</b> " + h.getName()
				+ "<br>" + "<b>Health:</b> " + h.getCurrentHp() + "<br>" + "<b>Attack Damage:</b> " + h.getAttackDmg()
				+ "<br>" + "<b>Actions Available:</b> " + h.getActionsAvailable() + "<br>" + "<b>Maximum Actions:</b> "
				+ h.getMaxActions() + "<br>" + "<b>Number of Vaccines:</b> " + h.getVaccineInventory().size() + "<br>"
				+ "<b>Number of Supplies:</b> " + h.getSupplyInventory().size() + "<br>" + "</p></html>";

		return s;
	}

	public String getZombieInfo(Zombie z) {
		String s = "<html><p>Type: Zombie</p>" + "<p>Name: " + z.getName() + "</p>" + "<p> Health: " + z.getCurrentHp()
				+ "</p>" + "<p>Attack Damage: " + z.getAttackDmg() + "</p></html>";

		return s;
	}

	public static void main(String[] args) {
		Frame f = new Frame();

	}
//	public void keyTyped(KeyEvent e) {
//		// TODO Auto-generated method stub
//
//	}

	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode() == KeyEvent.VK_DOWN) {
			try {
				selectedHero.move(Direction.UP);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_UP) {
			try {
				selectedHero.move(Direction.DOWN);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			try {
				selectedHero.move(Direction.RIGHT);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
		
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			try {
				selectedHero.move(Direction.LEFT);
				showMapOnButtons();
			} catch (MovementException | NotEnoughActionsException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage());
			}
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

//	public void keyReleased(KeyEvent e) {
//		// TODO Auto-generated method stub
//
//	}
//}
}